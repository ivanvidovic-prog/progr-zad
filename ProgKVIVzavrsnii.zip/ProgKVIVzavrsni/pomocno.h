#ifndef POMOCNO_H
#define POMOCNO_H

// KONCEPT 14: Zaštita parametara kod svih funkcija (korištenje const za ulaze)
/*Cilj zaštite parametara je osigurati da funkcija radi samo s valjanim ulaznim podacima te da se greške otkriju što ranije
i na jasnom mjestu u programu.*/

void OcistiUnosniSpremnik(void);
void SigurnoUcitajString(char* CiljniSpremnik, const unsigned int MaksDuljina);
int DohvatiValidiraniCijeliBroj(const int MinVrijednost, const int MaxVrijednost);
float DohvatiValidiraniRealniBroj(const float MinVrijednost, const float MaxVrijednost);   //KONCEPT 5 const (Zaključavanje vrijednosti varijable tako da je nitko u kodu ne može slučajno izmijeniti nakon što je jednom postavljena.)

#endif