#ifndef IZBORNIK_H
#define IZBORNIK_H

void PrikaziGlavniIzbornik(void);
void PrikaziIzbornikStatistike(void);
void PrikaziIzbornikPretrazivanja(void);
void PrikaziIzbornikSortiranja(void);

#endif