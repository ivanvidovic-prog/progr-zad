#ifndef ZAJEDNICKO_H
#define ZAJEDNICKO_H

// KONCEPT 11: Kod izbornika koristiti enum tipove ili makro simbole
#define DATOTEKA_SERVISA "servisi.dat"
#define PRIVREMENA_DATOTEKA "privremeni_servisi.dat"

// KONCEPT 8: Primjena extern ključne riječi za globalne varijable
//Značenje: Javna oglasna ploča. Označava varijablu koja je stvorena na jednom mjestu, ali je javno dostupna svim datotekama.
//extern int brojac; ne stvara novu varijablu, nego govori kompajleru da će se prava definicija pronaći u nekoj drugoj .c datoteci.
extern int ukupnoServisa;
extern float ukupniPrihod;

void AzurirajGlobalneVarijable(void);

#endif // ZAJEDNICKO_H