#ifndef SERVIS_H
#define SERVIS_H

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

// KONCEPT 15: Koristiti statički zauzeta polja
#define MAKS_NAZIV 50
#define MAKS_OPIS 200
#define MAKS_STATICKI_LIMIT 500  //makro simboli (#define)
#define SIGURNOSNA_KOPIJA_DATOTEKE "servisi_backup.dat"

// KONCEPT 9: Ako su funkcije jednostavne koristiti makro funkcije ili inline funkcije
// Brze matematičke zamjene koje pretprocesor odradi prije samog kompajliranja koda.
#define EUR_U_KN(x) ((x) * 7.53450f)

// KONCEPT 9: Primjena inline funkcije za brzi izračun poreza (PDV 25%)
static inline float IzracunajPorez(const float Iznos)
{
    return Iznos * 0.25f;
}

// KONCEPT 4: Primjena typedef s enum tipovima & KONCEPT 11: Enum za upravljanje izbornikom
// KONCEPT 11 Kod izbornika koristiti enum tipove ili makro simbole.

typedef enum GlavniIzbornikOpcija
{
    IZBORNIK_IZLAZ = 0, //Vrijednost = 0
    IZBORNIK_KREIRAJ,         //Vrijednost = 1
    IZBORNIK_CITAJ,
    IZBORNIK_AZURIRAJ,
    IZBORNIK_BRISI,
    IZBORNIK_STATISTIKA,
    IZBORNIK_PRETRAZI,
    IZBORNIK_SORTIRAJ   //Vrijednost = 7
} GlavniIzbornikOpcija;

typedef enum StatistikaOpcija
{
    STAT_NATRAG = 0,
    STAT_UKUPAN_BROJ,
    STAT_UKUPAN_PRIHOD,
    STAT_PROSJEK
} StatistikaOpcija;

typedef enum PretrazivanjeOpcija
{
    PRETRAGA_NATRAG = 0,
    PRETRAGA_LINEARNA_ID,
    PRETRAGA_LINEARNA_IME,
    PRETRAGA_BSEARCH_ID
} PretrazivanjeOpcija;

typedef enum SortiranjeOpcija
{
    SORT_NATRAG = 0,
    SORT_QSORT_ID,
    SORT_REKURZIVNI_CIJENA,
    SORT_QSORT_IME
} SortiranjeOpcija;

// KONCEPT 3: Odabir konkretnih složenih tipova podataka (Enum unutar strukture)
typedef enum StatusServisa
{
    STATUS_ZAPRIMLJEN = 0,
    STATUS_U_TIJEKU,
    STATUS_ZAVRSEN
} StatusServisa;

// KONCEPT 3: Odabir konkretnih složenih tipova podataka & KONCEPT 4: Typedef sa strukturama
//OPIS: struct-Grupiranje različitih tipova podataka (brojeva i tekstova) u jednu logičku cjelinu
// typedef-stvara nadimak za tip podatka da kod bude citljiviji (Primjer: Osoba osoba1; (Znaci novi naziv za tu cijelu strukturu))

//KONCEPT 15. Koristiti statički zauzeta polja gdje su potrebna
typedef struct RadniNalog
{
    // KONCEPT 2: Odabir konkretnih primitivnih tipova podataka (int i float)
    int idServisa;  // Primitivni tip (cijeli broj za jednistveni ID) - KONCEPT 2
    char imeKlijenta[MAKS_NAZIV];  // Niz znakova (string)
    char modelBicikla[MAKS_NAZIV];
    char opisKvara[MAKS_OPIS];
    char ugradeniDijelovi[MAKS_OPIS]; 
    float cijenaServisa;  // Primitivni tip (realni broj s decimalama za cijenu u EUR) - KONCEPT 2
    StatusServisa trenutniStatus;  // Enum tip podataka - KONCEPT 4 
    //(je korisnički definirani tip podataka koji omogućuje da imenuješ cijele brojeve pomoću simboličkih naziva.)
    // enum definira varijablu koja može poprimiti samo točno određene statuse (riječi kojima računalo dodjeljuje brojeve 0, 1, 2...).
} RadniNalog;

// KONCEPT 13: Generalna upotreba funkcija i struktura
// DOPUNSKI KONCEPT 1: Jednostruko ili dvostruko povezani popis (Čvor liste)
typedef struct CvorServisa
{
    RadniNalog podaci;
    struct CvorServisa* iduci;  // Pokazivač ("kuka") na idući vagon u listi KONCEPT DOPUNSKI 1
} CvorServisa;

//KONCEPT 1 CRUD
// KONCEPT 13: Generalna upotreba funkcija i struktura (Deklaracije CRUD operacija)
void KreirajRadniNalog(void);
void IspisiSveRadneNaloge(void);        //KONCEPT 5 PascalCase
void AzurirajRadniNalog(void);
void ObrisiRadniNalog(void);          //KONCEPT 5 PascalCase

// Izborničke pod-funkcije i obrada podataka
void UpravljajIzbornikomStatistike(void);
void UpravljajIzbornikomPretrazivanja(void);
void UpravljajIzbornikomSortiranja(void);

// Funkcije za rad s dinamičkom memorijom i vezanom listom
CvorServisa* UcitajDatotekuUListu(void);
void ZapisiListuUDatoteku(CvorServisa* glavaListe);
void OslobodiMemorijuListe(CvorServisa** glavaListe);

// KONCEPT 21: Implementacija funkcije za kopiranje datoteka (Backup sustav)
int KopirajBazuPodataka(const char* IzvornaDatoteka, const char* CiljnaDatoteka);

// Komparacijske funkcije za qsort i bsearch 
int UsporediPoIDu(const void* a, const void* b);  //KONCEPT 5 const (Zaključavanje vrijednosti varijable tako da je nitko u kodu ne može slučajno izmijeniti nakon što je jednom postavljena.)
int UsporediPoImenu(const void* a, const void* b);     //KONCEPT 5 PascalCase

#endif // SERVIS_H